export default function ImageItem() {
    return (<>
    </>);
}